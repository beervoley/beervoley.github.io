set -vex
#before_install: pyenv install 3.5.4 && pyenv global 3.5.4
#before_install: pyenv global 3.6
# https://docs.travis-ci.com/user/languages/python/
# "for Trusty, this means 2.7.6 and 3.4.3"

pyenv global 3.6

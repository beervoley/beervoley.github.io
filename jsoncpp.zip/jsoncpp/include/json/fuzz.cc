#include "writer.h"
#include "reader.h"
#include <iostream>


void FuzzMe(const uint8_t *data, size_t size) {
    Json::Reader reader;
    char* buffer = new char[size + 1];
    buffer[size] = 0;
    for(size_t i = 0; i < size; i++) {
        buffer[i] = (char) data[i];
    }
    Json::Value root;
    reader.parse(std::string(buffer), root);
}

extern "C" int LLVMFuzzerTestOneInput(const uint8_t *Data, size_t Size) {
    FuzzMe(Data, Size);
    return 0;  // Non-zero return values are reserved for future use.
}

